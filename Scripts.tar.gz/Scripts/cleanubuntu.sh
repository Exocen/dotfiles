echo "Script de nettoyage d'Ubuntu"
sudo apt-get autoclean
echo "Les résidus des logiciels supprimés"
sudo dpkg -P `dpkg -l | grep "^rc" | tr -s ' ' | cut -d ' ' -f 2`
echo "Supprimer les logiciels orphelins"
sudo apt-get autoremove --purge `deborphan` 
echo "Les paquets périmés ont été supprimés OK"
sleep 3
find ~/.thumbnails -type f -atime +7 -exec rm {} \;
echo "Icônes supprimés"
rm -r -f ~/.local/share/Trash/files/* 
echo "Corbeille vidée"
rm ~/.local/share/recently-used*
echo "Suppression Documents Recents"
sleep 3
find ~/ -name '*~' -exec rm {} \;
echo "Fichiers temporaires (terminant par ~) du dossier HOME ont été suprimmés"
echo "Nettoyage du l'historique du bash"
sleep 3
rm ~/.bash_history
history -c
echo "Nettoyage terminé"
