# Ne pas oublier de mettre en root

echo "Vidage du cache de la mémoire RAM"

sync
sysctl -w vm.drop_caches=3
sysctl -w vm.drop_caches=0
echo "1" > /proc/sys/vm/drop_caches
sleep 1

echo "0" > /proc/sys/vm/drop_caches

echo "Vidage du cache terminé"
