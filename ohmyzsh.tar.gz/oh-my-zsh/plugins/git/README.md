## git
**Maintainer:** [Stibbons](https://github.com/Stibbons)

This plugin adds several git aliases and increase the completion function provided by zsh
